const abi =[
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "entreprise",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "remuneration",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint32",
				"name": "delai",
				"type": "uint32"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint8",
				"name": "min_reputation",
				"type": "uint8"
			}
		],
		"name": "InscriptionDemandeok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "illustrateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "nom",
				"type": "string"
			}
		],
		"name": "InscriptionIllustrateurok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "Illustrateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "offre",
				"type": "bytes32"
			}
		],
		"name": "Postulationok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "donateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint8",
				"name": "credit",
				"type": "uint8"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "recepteur",
				"type": "address"
			}
		],
		"name": "TransReputok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "offre",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			}
		],
		"name": "accepterOffreok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "url",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "travail",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			}
		],
		"name": "accepterlivraisonok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "illustrateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "hashtravail",
				"type": "bytes32"
			}
		],
		"name": "livraisonok",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_illustrateur",
				"type": "address"
			},
			{
				"internalType": "bytes32",
				"name": "_demande",
				"type": "bytes32"
			}
		],
		"name": "acceptelivraison",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_Postulant",
				"type": "address"
			},
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "accepterOffre",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "addReputIllustrateur",
		"outputs": [
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_remuneration",
				"type": "uint256"
			},
			{
				"internalType": "uint32",
				"name": "_delai",
				"type": "uint32"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "uint8",
				"name": "_min_reputation",
				"type": "uint8"
			}
		],
		"name": "ajouterDemande",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_nom",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_portfolio",
				"type": "string"
			}
		],
		"name": "inscriptionIllustrateur",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_url",
				"type": "string"
			},
			{
				"internalType": "bytes32",
				"name": "_demande",
				"type": "bytes32"
			}
		],
		"name": "livraison",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "postuler",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			},
			{
				"internalType": "uint8",
				"name": "_cred",
				"type": "uint8"
			}
		],
		"name": "TransReputIllustrateur",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hash",
				"type": "bytes32"
			}
		],
		"name": "afficherDemande",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			},
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "afficherDemandebis",
		"outputs": [
			{
				"components": [
					{
						"internalType": "address",
						"name": "entreprise",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "remuneration",
						"type": "uint256"
					},
					{
						"internalType": "uint32",
						"name": "delai",
						"type": "uint32"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "uint8",
						"name": "min_reputation",
						"type": "uint8"
					},
					{
						"internalType": "enum PdmIllustrateurs.statutDemande",
						"name": "statut",
						"type": "uint8"
					},
					{
						"internalType": "address[]",
						"name": "candidats",
						"type": "address[]"
					},
					{
						"internalType": "uint8",
						"name": "numero_candidat",
						"type": "uint8"
					},
					{
						"internalType": "bytes32",
						"name": "hashtravailremis",
						"type": "bytes32"
					},
					{
						"internalType": "uint256",
						"name": "date",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "url",
						"type": "string"
					}
				],
				"internalType": "struct PdmIllustrateurs.Demande",
				"name": "",
				"type": "tuple"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "afficherUrlTravail",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "hashDemande",
				"type": "bytes32"
			}
		],
		"name": "demandeExiste",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_numDemande",
				"type": "uint256"
			}
		],
		"name": "getHashDemande",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "getIllustrateurinfo",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getIllustrateurs",
		"outputs": [
			{
				"internalType": "address payable[]",
				"name": "",
				"type": "address[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "getIllustrateurtravail",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "getReputIllustrateur",
		"outputs": [
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "IllustrateurComptes",
		"outputs": [
			{
				"internalType": "address payable",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "illustrateurMembre",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "listerDemandes",
		"outputs": [
			{
				"components": [
					{
						"internalType": "address",
						"name": "entreprise",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "remuneration",
						"type": "uint256"
					},
					{
						"internalType": "uint32",
						"name": "delai",
						"type": "uint32"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "uint8",
						"name": "min_reputation",
						"type": "uint8"
					},
					{
						"internalType": "enum PdmIllustrateurs.statutDemande",
						"name": "statut",
						"type": "uint8"
					},
					{
						"internalType": "address[]",
						"name": "candidats",
						"type": "address[]"
					},
					{
						"internalType": "uint8",
						"name": "numero_candidat",
						"type": "uint8"
					},
					{
						"internalType": "bytes32",
						"name": "hashtravailremis",
						"type": "bytes32"
					},
					{
						"internalType": "uint256",
						"name": "date",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "url",
						"type": "string"
					}
				],
				"internalType": "struct PdmIllustrateurs.Demande[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "nbredemandes",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "TabDemandes",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"name": "TravauxMap",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]; //cf. PlacedemarcheIllustrateur.sol

var AddresseUser ="";

async function createMetaMaskDapp() {
  try {
    // Demande à MetaMask l'autorisation de se connecter
    const addresses = await ethereum.enable();
    const address = addresses[0];
    // Connection au noeud fourni par l'objet web3
    const provider = new ethers.providers.Web3Provider(ethereum);
    dapp = { address, provider };
    console.log(dapp);
    console.log(dapp.address);
    AddresseUser = dapp.address;
	 document.getElementById('adresseUser').innerHTML = AddresseUser;    
    document.getElementsByClassName("needMetaMask")[0].className = "needMetaMask";
  } catch (err) {
    // Gestion des erreurs
    console.error(err);
  }
}

async function instantiatePDM() {
  if (typeof dapp === "undefined") { await createMetaMaskDapp(); }
  let contractAddress = document.getElementById("contractAddress").value;
  contratPDM = new ethers.Contract(contractAddress, abi, dapp.provider.getSigner());
  resultat = "contrat " + contractAddress + " chargé !"
  document.getElementById('result').innerHTML = resultat; 
}



async function EnregistrerIllus() {
   let nom = document.getElementById("nom").value;
   let portfolio = document.getElementById("portfolio").value;
   let inscrireok = await contratPDM.inscriptionIllustrateur(nom, portfolio);
   console.log("L'enregistrement a été effectué ... wait ...");
   contratPDM.on('InscriptionIllustrateurok', (illustrateur, nom) => {
   let See = "nom : " + nom + " à l'adresse ... : " + illustrateur;
   console.log(See);
   document.getElementById('illus').innerHTML = illustrateur;
   document.getElementById('name').innerHTML = nom;
   document.getElementById('siteportfolio').innerHTML = portfolio;
   });
 }


async function DeposerDemande() {
   let remuneration = document.getElementById("remuneration").value;
   let delai = document.getElementById("delai").value;

    var seconds = parseInt(delai, 10);

    var days = Math.floor(seconds / (3600*24));
    seconds  -= days*3600*24;
    var hrs   = Math.floor(seconds / 3600);
    seconds  -= hrs*3600;
    var mnts = Math.floor(seconds / 60);
    seconds  -= mnts*60;
    console.log(days+" days, "+hrs+" Hrs, "+mnts+" Minutes, "+seconds+" Seconds");
    let delay = days+" Jours, "+hrs+" Heures, "+mnts+" Minutes, "+seconds+" Secondes"; 


   let description = document.getElementById("description").value;
   let reputation = document.getElementById("reputation").value;
	
	// Convert from wei to ether (string)
	let remuether = ethers.utils.formatEther(remuneration);	
	console.log("convert " + remuether);
	
	let remuforvalue = ethers.utils.parseEther(remuether);
	console.log("remu for value " + remuether);
	
	let remiseok = await contratPDM.ajouterDemande(remuneration, delai, description, reputation, {value : remuforvalue});
	
   console.log("La demande a été déposée ... wait ...");
   contratPDM.on('InscriptionDemandeok', (entreprise,remuneration,delai,description,min_reputation) => {
   let See = "description : " + description + " par ... : " + entreprise + " à remettre dans... " + delay;
   console.log(See);
   document.getElementById('entreprise').innerHTML = entreprise;
   document.getElementById('rem').innerHTML = remuneration;
   document.getElementById('del').innerHTML = delay;	
   document.getElementById('des').innerHTML = description;
   document.getElementById('rep').innerHTML = min_reputation;	
   });

 }


function timeConverter(UNIX_timestamp){
  var a = new Date(UNIX_timestamp * 1000);
  var months = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
  var year = a.getFullYear();
  var month = months[a.getMonth()];
  var date = a.getDate();
  var hour = a.getHours();
  var min = a.getMinutes();
  var sec = a.getSeconds();
  var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
  return time;
}


async function ListerDemandes() {
    let nbredemandes = await contratPDM.nbredemandes();
    console.log(" nombre de demandes " + nbredemandes); 	
//  document.getElementById('nbredemandes').innerHTML = nbredemandes;


    var demandes = new Array();
    
	 		
	 const Statuts = {
    0: 'OUVERTE',
    1: 'EN COURS',
    2: 'FERMEE',
    3: 'INCONNU'
    }

    demandes = await contratPDM.listerDemandes();
    let contenu = "<table><tbody><tr><th>num</th><th>date de la demande</th><th>Adresse de l'entreprise</th><th>rémunération (en wei)</th><th>description</th><th>réputation</th><th>date limite</th><th>Statut</th><th>Illustrateurs</th><th>Hash</th></tr>";
    
    // var illustrateurs = new Array();
    
    for(i=0; i < nbredemandes; i ++)
   {     
		datetimestamp = demandes[i][9];
		//console.log("from Smart ", demandes[i][0]);
		//console.log("from Metamask ", AddresseUser);
		if (demandes[i][0].toLowerCase() === AddresseUser.toLowerCase()){
		contenu += "<tr class=greeny>";
		}
		else {
		contenu += "<tr class=redy>";				
		}

		contenu += "<tr>";
		num = i +1;
		contenu += "<td>" + num + "</td>";

		contenu += "<td>" + timeConverter(datetimestamp) + "</td>";
		contenu += "<td>" + "<a href= http://ropsten.etherscan.io/address/" + demandes[i][0] + " target=_blank>"+ demandes[i][0].substring(0,10) + "..." + "</a>" + "</td>";
		contenu += "<td>" + demandes[i][1] + "</td>"; // remuneration		
		contenu += "<td>" + demandes[i][3] + "</td>"; // description
		contenu += "<td>" + demandes[i][4] + "</td>"; // reputation
 	
	
	 	datelimitetimestamp = parseInt(demandes[i][2], 10) + parseInt(demandes[i][9], 10);
	
		contenu += "<td>" + timeConverter(datelimitetimestamp) + "</td>"; // datelimite
		
		//let statut = Statuts.numstatut;
		let numstatut = demandes[i][5];
		if (numstatut == 0) {statut = "OUVERTE";}
		if (numstatut == 1) {statut = "EN COURS";}
		if (numstatut == 2) {statut = "FERMEE";}


		contenu += "<td>" + statut + "</td>"; // Statut

	   var illustrateurs = new Array();

		illustrateurs = demandes[i][6];
		console.log("nombre d'illustrateurs pour cette demande : ", illustrateurs.length);
		
		contenu += "<td>"; 
						
		for (j =0; j < illustrateurs.length; j++) {
				
		console.log("j : ", j);
		console.log("adresse : ", illustrateurs[j]);
			if (j + 1 === parseInt(demandes[i][7],10)) { // s'il est enregistré comme candidat 
			contenu += "Candidat => ";	
			}
			else {
			contenu += "Postulant => ";	
			}		
		contenu += "<a href= http://ropsten.etherscan.io/address/" + illustrateurs[j].toLowerCase() + " target=_blank>"+ illustrateurs[j].substring(0,10) + "..." + "</a>";
		contenu += "<br>";					
		}

		// contenu += illustrateurs;

		contenu += "</td>";
		
		let hashdemande = await contratPDM.getHashDemande(i);
		console.log(" hash de la demande " + hashdemande);
		contenu += "<td>" + hashdemande + "</td>";
    	 	
		
		// contenu += "<td>" + "hash à venir ..." + "</td>";
		
		contenu += "</tr>";
   }	
   contenu += "</tbody></table>";
	document.getElementById('contenu').innerHTML = contenu;	
}


async function ListerDemandesBis() { // fonction d'affichage pour les illustrateurs - la réputation doit être suffisante
    let nbredemandes = await contratPDM.nbredemandes();
    console.log(" nombre de demandes " + nbredemandes); 	
//  document.getElementById('nbredemandes').innerHTML = nbredemandes;
    var demandes = new Array();
	 		
	 const Statuts = {
    0: 'OUVERTE',
    1: 'EN COURS',
    2: 'FERMEE',
    3: 'INCONNU'
    }

    demandes = await contratPDM.listerDemandes();
    let contenu = "<table><tbody><tr><th>num</th><th>date demande</th><th>Adresse de l'entreprise</th><th>rémunération en Microether</th><th>description</th><th>réput.</th><th>Jour/H</th><th>Statut</th><th>Hash</th></tr>";
    for(i=0; i < nbredemandes; i ++)
   {     
		datetimestamp = demandes[i][9];
		//console.log("from Smart ", demandes[i][0]);
		//console.log("from Metamask ", AddresseUser);
		
		
		
		
		let reputation = await contratPDM.getReputIllustrateur(AddresseUser);
		
		
		
		// if (demandes[i][0].toLowerCase() === AddresseUser.toLowerCase() && ){

		let numstatut = demandes[i][5];
		if (numstatut == 0) {statut = "OUVERTE";}
		if (numstatut == 1) {statut = "EN COURS";}
		if (numstatut == 2) {statut = "FERMEE";}

		
		console.log("Addresse interrogée : ", AddresseUser);		
		console.log("Reputation : ", reputation);		
		
//		if (reputation >= demandes[i][4] && numstatut ==0){		


		if (parseInt(reputation,10) >= parseInt(demandes[i][4],10)){
		contenu += "<tr class=greeny>";
		}
		else {
		contenu += "<tr class=redy>";				
		}

		contenu += "<tr>";
		num = i +1;
		contenu += "<td>" + num + "</td>";

		contenu += "<td>" + timeConverter(datetimestamp) + "</td>";
		contenu += "<td>" + "<a href= http://ropsten.etherscan.io/address/" + demandes[i][0] + " target=_blank>"+ demandes[i][0].substring(0,10) + "..." + "</a>" + "</td>";
		// remuneration en Micro-ether
		let remun = demandes[i][1] * Math.pow(10, -12);
		contenu += "<td>" + remun + "</td>"; // remuneration

		contenu += "<td>" + demandes[i][3] + "</td>"; // description		
		contenu += "<td>" + demandes[i][4] + "</td>"; // reputation
 	
		let delai_en_secondes = parseInt(demandes[i][2],10); 
		let delaijourhomme = Math.floor(delai_en_secondes / (3600 * 8)); // 8 heures par jour de travail
		
		contenu += "<td>" + delaijourhomme +  "</td>"; // délai	
		
		contenu += "<td>" + statut + "</td>"; // Statut


		let hashdemande = await contratPDM.getHashDemande(i);
		console.log(" hash de la demande " + hashdemande);
		contenu += "<td>" + hashdemande + "</td>";
    	 	
		
		// contenu += "<td>" + "hash à venir ..." + "</td>";
		
		contenu += "</tr>";
   }	
   contenu += "</tbody></table>";
	document.getElementById('contenu').innerHTML = contenu;	
}




