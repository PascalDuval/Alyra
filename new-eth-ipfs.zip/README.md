Cette interface créée avec react permet à l’utilisateur de :

    Charger un fichier sur IPFS.
    Choisir si le fichier doit être simplement ajouté (avec un montant par défaut de 0.001 ether) ou épinglé (le montant est alors de 0.1 ether)
    inscrire le Hash IPFS directement sur la blockchain (car il est inscrit dans les data de la transaction)


nota bene : il faut être connecté sur un noeud IPFS local localhost:3000. Il est alors possible de voir votre fichier sur une gateway IPFS. Pour passer par un noeud public, il faut modifier le fichier ipfs.js

