import React, { Component } from 'react';
import './App.css';
import web3 from './web3';
import ipfs from './ipfs';
import storehash from './storehash';

class App extends Component {
    state = {
      ipfsHash:null,
      epinglage:'true',
      buffer:'',
      ethAddress:'',
      transactionHash:'',
		blockNumber:'',
      gasUsed: '',            
      montant:'100000000000000000',
      txReceipt: ''   
    };
   
	

	setChoix(event) {
    console.log('epinglage ? : ' + event.target.value);
	 if (event.target.value === 'true'){
			this.setState({ epinglage:'true'});
			this.setState({ montant :'100000000000000000'}); // on renseigne directement en wei 
			} 
    else {
    	this.setState({ epinglage:'false'});
		this.setState({ montant :'1000000000000000'}); // on renseigne directement en wei
    }
	}
	 
    captureFile =(event) => {
        event.stopPropagation()
        event.preventDefault()
        const file = event.target.files[0]
        let reader = new window.FileReader()
        reader.readAsArrayBuffer(file)
        reader.onloadend = () => this.convertToBuffer(reader)    
    };

    convertToBuffer = async(reader) => {
        const buffer = await Buffer.from(reader.result);
        this.setState({buffer});
    };

    onClick = async () => {
    try{
        //this.setState({blockNumber: "En attente.."});
        //this.setState({gasUsed: "En attente..."});
        //this.setState({valeur: "En attente..."}); pas sûr que ça marche ...
        
			// cf . https://web3js.readthedocs.io/en/1.0/web3-eth.html#gettransactionreceipt        
        
        await web3.eth.getTransactionReceipt(this.state.transactionHash, (err, txReceipt)=>{
        console.log(err,txReceipt);
        this.setState({txReceipt});        
        });
        
		  //await this.setState({blockNumber: this.state.txReceipt.blockNumber});        
		  //await this.setState({gasUsed: this.state.txReceipt.gasUsed});
		  //await this.setState({valeur: this.state.txReceipt.value});	pas sûr que ça marche ...
        } //try


    catch(error){
         console.log(error);
      	} //catch
  		} //onClick

    onSubmit = async (event) => {
      event.preventDefault();
      const accounts = await web3.eth.getAccounts(); // appeler le compte metamask
     
      console.log('Envoi du compte metamask: ' + accounts[0]);
      const ethAddress= await storehash.options.address; //obtenir l'adresse du contrat positionné dans storehash.js
      this.setState({ethAddress});

		console.log("epinglage : ", this.state.epinglage);
		console.log("montant : ", this.state.montant);

      // sauver le document sur IPFS, retourner son hash et positionner le state
      // pour épingler il suffira de mettre l'option pin à true cf  : https://github.com/ipfs/interface-ipfs-core/blob/master/SPEC/FILES.md#add 
     	
      await ipfs.add(this.state.buffer, {pin:this.state.epinglage}, (err, ipfsHash) => {
      console.log(err,ipfsHash); 
      this.setState({ ipfsHash:ipfsHash[0].hash });     //setState en renseignant ipfsHash par ipfsHash[0].hash 

      // On utilise ici la méthode myContract.methods.myMethod([param1[, param2[, ...]]]).send(options[, callback]
		storehash.methods.sendHash(this.state.ipfsHash).send({from: accounts[0], value:this.state.montant}, (error, transactionHash) => {	
      console.log("transactionhash : ", transactionHash);
      this.setState({transactionHash});
      
      }); 
      
		// lientx= 'https://rinkeby.etherscan.io/tx/' + this.state.transactionHash;
	      	      
	   }) //await ipfs.add simple ou avec pin selon l'option choisie..
	     
    }; //onSubmit 
  
  
    render() {
      
      return (
        <div className="App">
          <header className="App-header">
            <h1> Ethereum et InterPlanetary File System(IPFS) avec Create React App</h1>
          </header>
          
          <br></br>
          <div align="left">
			 Cette interface permet à l’utilisateur de :
			 <ol>
			 <li>Charger un fichier sur IPFS.</li> 
			 <li>Choisir si le fichier doit être simplement ajouté (avec un montant par défaut de 0.001 ether) ou épinglé (le montant est alors de 0.1 ether)</li>
			 <li>inscrire le Hash IPFS directement sur la blockchain</li>
			 </ol>
			 </div>
			
			<br></br>

	
			
          
          <hr />

          <h2 align = "left"> Choisir une fichier pour envoyer sur IPFS et en conserver le Hash sur la blockchain</h2>
          <form onSubmit={this.onSubmit}>
            <input  type = "file" onChange = {this.captureFile} /><br></br>
            
            
             <h3 align = "left">Souhaitez vous, par ailleurs, épingler ce fichier ?</h3>
             <br></br>
            
             <div onChange={this.setChoix.bind(this)}>
             <strong>oui</strong> (le montant sera de <strong><em>0.1 ether</em></strong> [mais affiché en wei]) : <input type="radio" value="true" defaultChecked name="pin"/><br></br>
 
             <strong>non</strong> (le montant sera de <em><strong>0.001 ether</strong></em> [mais affiché en wei]): <input type="radio" value="false" name="pin"/><br></br>
				 </div>  				
  				
  				<br></br>
  				<br></br>
             <button type="submit">Envoyer</button>
			
          </form>
					
					<br></br>
					<br></br>																																																																																																																																																																															
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						

              <table border ="true" align="center">
                <thead>
                  <tr>
                    <th>Retour</th>
                    <th>Valeur</th>
                  </tr>
                </thead>
               
                <tbody>

   
                  <tr>
                    <td align="left">Adresse du contrat Ethereum (testnet Rinkeby)</td>
                    <td align="right">{this.state.ethAddress}</td>
                  </tr>
                  
                 	<tr>
                    <td align="left">Epinglage</td>
                    <td align="right">{this.state.epinglage}</td>
                  </tr>                  

                 <tr>
                    <td align="left">Montant (en wei) à envoyer au contrat</td>
                    <td align="right">{this.state.montant}</td>
                  </tr>                  

                  <tr>
                    <td align="left">Hash IPFS enregistré sur le contrat ETH (vérifier sur "https://gateway.ipfs.io/ipfs/")</td>
                    <td align="right">{this.state.ipfsHash}</td>
                  </tr>

                  <tr>
                    <td align="left"><a href="https://rinkeby.etherscan.io/" target="_blank">Vérifier sur rinkeby une fois reçu le hash de la transaction</a></td>
                    <td align="right">{this.state.transactionHash}</td>
                  </tr>
  
                </tbody>
            </table>
        
     </div>
      );
    } //render
}

export default App;