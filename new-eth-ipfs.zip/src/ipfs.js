//on peut utiliser le noeud infura.io node 
// const IPFS = require(‘ipfs-api’);
// const ipfs = new IPFS({ host: ‘ipfs.infura.io’, port: 5001, protocol: ‘https’ });


//mais on va utiliser ici un local dameon
const ipfsApi = require('ipfs-api');
const ipfs = new ipfsApi('localhost', '5001', {protocol:'http'});
export default ipfs;