import web3 from './web3';

//accéder à la copie locale du contrat déployé sur rinkeby testnet
// ancien const address = '0x1e387e66802c779d74acbcb916a253d74c6d7b10';

const address =  '0x81a35c5acfb7f8f81d7a79e2f58942605a832aef';

// ABI du contrat 

const abi = [
	{
		"constant": false,
		"inputs": [
			{
				"name": "x",
				"type": "string"
			}
		],
		"name": "sendHash",
		"outputs": [],
		"payable": true,
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getHash",
		"outputs": [
			{
				"name": "x",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	}
]



export default new web3.eth.Contract(abi,address);