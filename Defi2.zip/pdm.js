const abi =[
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "entreprise",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "remuneration",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint32",
				"name": "delai",
				"type": "uint32"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint8",
				"name": "min_reputation",
				"type": "uint8"
			}
		],
		"name": "InscriptionDemandeok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "illustrateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "nom",
				"type": "string"
			}
		],
		"name": "InscriptionIllustrateurok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "Illustrateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "offre",
				"type": "bytes32"
			}
		],
		"name": "Postulationok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "offre",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			}
		],
		"name": "accepterOffreok",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address payable",
				"name": "illustrateur",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "bytes32",
				"name": "hashtravail",
				"type": "bytes32"
			}
		],
		"name": "livraisonok",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_Postulant",
				"type": "address"
			},
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "accepterOffre",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "addReputIllustrateur",
		"outputs": [
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			}
		],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_remuneration",
				"type": "uint256"
			},
			{
				"internalType": "uint32",
				"name": "_delai",
				"type": "uint32"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "uint8",
				"name": "_min_reputation",
				"type": "uint8"
			}
		],
		"name": "ajouterDemande",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_nom",
				"type": "string"
			}
		],
		"name": "inscriptionIllustrateur",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_url",
				"type": "string"
			},
			{
				"internalType": "bytes32",
				"name": "_demande",
				"type": "bytes32"
			}
		],
		"name": "livraison",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "postuler",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hash",
				"type": "bytes32"
			}
		],
		"name": "afficherDemande",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			},
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "enum PdmIllustrateurs.statutDemande",
				"name": "",
				"type": "uint8"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "_hashDemande",
				"type": "bytes32"
			}
		],
		"name": "afficherDemandebis",
		"outputs": [
			{
				"components": [
					{
						"internalType": "address",
						"name": "entreprise",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "remuneration",
						"type": "uint256"
					},
					{
						"internalType": "uint32",
						"name": "delai",
						"type": "uint32"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "uint8",
						"name": "min_reputation",
						"type": "uint8"
					},
					{
						"internalType": "enum PdmIllustrateurs.statutDemande",
						"name": "statut",
						"type": "uint8"
					},
					{
						"internalType": "address[]",
						"name": "candidats",
						"type": "address[]"
					},
					{
						"internalType": "uint8",
						"name": "numero_candidat",
						"type": "uint8"
					},
					{
						"internalType": "bytes32",
						"name": "hashtravailremis",
						"type": "bytes32"
					},
					{
						"internalType": "uint256",
						"name": "date",
						"type": "uint256"
					}
				],
				"internalType": "struct PdmIllustrateurs.Demande",
				"name": "",
				"type": "tuple"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "bytes32",
				"name": "hashDemande",
				"type": "bytes32"
			}
		],
		"name": "demandeExiste",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getIllustrateurs",
		"outputs": [
			{
				"internalType": "address[]",
				"name": "",
				"type": "address[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_address",
				"type": "address"
			}
		],
		"name": "getReputIllustrateur",
		"outputs": [
			{
				"internalType": "uint8",
				"name": "",
				"type": "uint8"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "IllustrateurComptes",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "illustrateurMembre",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "listerDemandes",
		"outputs": [
			{
				"components": [
					{
						"internalType": "address",
						"name": "entreprise",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "remuneration",
						"type": "uint256"
					},
					{
						"internalType": "uint32",
						"name": "delai",
						"type": "uint32"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "uint8",
						"name": "min_reputation",
						"type": "uint8"
					},
					{
						"internalType": "enum PdmIllustrateurs.statutDemande",
						"name": "statut",
						"type": "uint8"
					},
					{
						"internalType": "address[]",
						"name": "candidats",
						"type": "address[]"
					},
					{
						"internalType": "uint8",
						"name": "numero_candidat",
						"type": "uint8"
					},
					{
						"internalType": "bytes32",
						"name": "hashtravailremis",
						"type": "bytes32"
					},
					{
						"internalType": "uint256",
						"name": "date",
						"type": "uint256"
					}
				],
				"internalType": "struct PdmIllustrateurs.Demande[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "nbredemandes",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "TabDemandes",
		"outputs": [
			{
				"internalType": "bytes32",
				"name": "",
				"type": "bytes32"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]; //cf. PlacedemarcheIllustrateur.sol

async function createMetaMaskDapp() {
  try {
    // Demande à MetaMask l'autorisation de se connecter
    const addresses = await ethereum.enable();
    const address = addresses[0];
    // Connection au noeud fourni par l'objet web3
    const provider = new ethers.providers.Web3Provider(ethereum);
    dapp = { address, provider };
    console.log(dapp);
    document.getElementsByClassName("needMetaMask")[0].className = "needMetaMask";
  } catch (err) {
    // Gestion des erreurs
    console.error(err);
  }
}

async function instantiatePDM() {
  if (typeof dapp === "undefined") { await createMetaMaskDapp(); }
  let contractAddress = document.getElementById("contractAddress").value;
  contratPDM = new ethers.Contract(contractAddress, abi, dapp.provider.getSigner());
//  document.getElementById("remuneration").parentElement.className = "";
}



async function EnregistrerIllus() {
   let nom = document.getElementById("nom").value;
   let inscrireok = await contratPDM.inscriptionIllustrateur(nom);
   console.log("L'enregistrement a été effectué ... ");
   contratPDM.on('InscriptionIllustrateurok', (illustrateur, nom) => {
   let See = "nom : " + nom + " à l'adresse ... : " + illustrateur;
   console.log(See);
   document.getElementById('illus').innerHTML = illustrateur;
   document.getElementById('name').innerHTML = nom;
   });
 }




async function DeposerDemande() {
   let remuneration = document.getElementById("remuneration").value;
   let delai = document.getElementById("delai").value;

    var seconds = parseInt(delai, 10);

    var days = Math.floor(seconds / (3600*24));
    seconds  -= days*3600*24;
    var hrs   = Math.floor(seconds / 3600);
    seconds  -= hrs*3600;
    var mnts = Math.floor(seconds / 60);
    seconds  -= mnts*60;
    console.log(days+" days, "+hrs+" Hrs, "+mnts+" Minutes, "+seconds+" Seconds");
    let delay = days+" Jours, "+hrs+" Heures, "+mnts+" Minutes, "+seconds+" Secondes"; 


   let description = document.getElementById("description").value;
   let reputation = document.getElementById("reputation").value;

   let remiseok = await contratPDM.ajouterDemande(remuneration, delai, description, reputation);
   console.log("La demande a été déposée ... ");
   contratPDM.on('InscriptionDemandeok', (entreprise,remuneration,delai,description,min_reputation) => {
   let See = "description : " + description + " par ... : " + entreprise + " à remettre dans... " + delay;
   console.log(See);
   document.getElementById('entreprise').innerHTML = entreprise;
   document.getElementById('rem').innerHTML = remuneration;
   document.getElementById('del').innerHTML = delay;	
   document.getElementById('des').innerHTML = description;
   document.getElementById('rep').innerHTML = min_reputation;	
   });

 }


async function ListerDemandes() {
    let nbredemandes = await contratPDM.nbredemandes();
    console.log(" nombre de demandes " + nbredemandes); 	
    document.getElementById('nbredemandes').innerHTML = nbredemandes;
    var demandes = new Array();
    demandes = await contratPDM.listerDemandes();
    for(i=0; i < nbredemandes; i ++)
   {    
    document.getElementById('demandes').innerHTML = "<li>" + demandes[i] + document.getElementById('demandes').innerHTML;

   }	
	
}


function timeConverter(UNIX_timestamp){
  var a = new Date(UNIX_timestamp * 1000);
  var months = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
  var year = a.getFullYear();
  var month = months[a.getMonth()];
  var date = a.getDate();
  var hour = a.getHours();
  var min = a.getMinutes();
  var sec = a.getSeconds();
  var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
  return time;
}



async function ListerDemandesBis() {
    let nbredemandes = await contratPDM.nbredemandes();
    var demandes = new Array();
    demandes = await contratPDM.listerDemandes();
    document.write("<table><tbody><tr><th>date de la demande</th><th>Adresse de l'entreprise</th><th>remuneration</th><th>description</th><th>date limite</th></tr>");
  for(i=0; i < nbredemandes; i ++) // autre présentation
   {    
    document.write("<tr>");

    console.log(" ... raw .." + demandes[i]); 


    datetimestamp = demandes[i][9];

    document.write("<td id=date");
    document.write(i);
    document.write("></td>");
    document.getElementById('date' + i).innerHTML =  timeConverter(datetimestamp);



    document.write("<td id=adresse");
    document.write(i);
    document.write("></td>");
    
    document.getElementById('adresse' + i).innerHTML = "<a href= http://ropsten.etherscan.io/address/" + demandes[i][0] + " target=_blank>"+ demandes[i][0].substring(0,10) + "..." + "</a>";



    document.write("<td id=remuneration");
    document.write(i);
    document.write("></td>");
    document.getElementById('remuneration' + i).innerHTML = demandes[i][1];
    
    document.write("<td id=description");
    document.write(i);
    document.write("></td>");
    document.getElementById('description' + i).innerHTML = demandes[i][3];	

    datelimitetimestamp = parseInt(demandes[i][2], 10) + parseInt(demandes[i][9], 10);
    document.write("<td id=datelimite");
    document.write(i);
    document.write("></td>");
    document.getElementById('datelimite' + i).innerHTML = timeConverter(datelimitetimestamp);

    document.write("/<tr>");

    }
         
    document.write("</tbody></table>");	

}













