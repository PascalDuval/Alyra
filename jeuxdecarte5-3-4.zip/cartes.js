const abi =[
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"name": "TabHash",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "string",
				"name": "s",
				"type": "string"
			}
		],
		"name": "ajouterCarte",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "nbrecartes",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "uint256",
				"name": "ind",
				"type": "uint256"
			}
		],
		"name": "recuperer",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	}
]; //cf. jeuxdecartes.sol

var AddresseUser ="";

async function createMetaMaskDapp() {
  try {
    // Demande à MetaMask l'autorisation de se connecter
    const addresses = await ethereum.enable();
    const address = addresses[0];
    // Connection au noeud fourni par l'objet web3
    const provider = new ethers.providers.Web3Provider(ethereum);
    dapp = { address, provider };
    console.log(dapp);
    console.log(dapp.address);
    AddresseUser = dapp.address;
	 document.getElementById('adresseUser').innerHTML = AddresseUser;    
    document.getElementsByClassName("needMetaMask")[0].className = "needMetaMask";
  } catch (err) {
    // Gestion des erreurs
    console.error(err);
  }
}

async function instantiateCarte() {
  if (typeof dapp === "undefined") { await createMetaMaskDapp(); }
  let contractAddress = document.getElementById("contractAddress").value;
  contratCartes = new ethers.Contract(contractAddress, abi, dapp.provider.getSigner());
  resultat = "contrat " + contractAddress + " chargé !"
  document.getElementById('result').innerHTML = resultat; 
}



async function EnregistrerCarte() {
   let hashipfs = document.getElementById("hashtosm").value;
   let numero = await contratCartes.ajouterCarte(hashipfs);
   console.log("L'enregistrement a été effectué ... avec le numéro : ", numero);

// document.getElementById("imageRecup").src = "data:image/jpg;base64,"+ resultat.toString('base64')

	retour = "le hash  " + hashipfs + " a été ajouté"
	document.getElementById('returnformsmart').innerHTML = retour
	
 }
 

async function ListerCartes() { 
	  let nbrecartes = await contratCartes.nbrecartes();
	  console.log(" nombre de cartes " + nbrecartes); 	
     // var CartesTab = new Array();
	  // Cartes = await contratPDM.listerDemandes();
    // let liste = "<OL>";
    for(i=0; i < nbrecartes && i < 10 ; i ++) // on ne veut que les 10 premières
   	{     
		let hashipfs = await contratCartes.recuperer(i);		
		console.log("hashipfs : ", hashipfs);
		
		let url = "https://ipfs.io/ipfs/" + hashipfs
		console.log(`Url --> ${url}`)
      // document.getElementById("hashipfs").innerHTML = hashipfs
      // document.getElementById("url").innerHTML= url
      // document.getElementById("url").href= url
      num = i+1;
      champretour = "imageRecup" + num
      document.getElementById(champretour).src = url		
		
				
		// liste = "<li>"		

	  // document.getElementById('listecartes').innerHTML = liste;	
	  }
}




